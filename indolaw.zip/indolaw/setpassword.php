<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Password</title>
    <?php include("head.php"); ?>
</head>
<body>
    <style> 
    body{
    min-height: 100vh;
    }
    form{ 
        width: 100% !important; 
        border: solid;
        padding: 100px;
        border-radius: 30px;
    }
    i{
          position: absolute !important;
          right: 20px;
          top: 20%; 
          font-size: 20px;
          cursor: pointer;
    }
    @media(max-width:768px){
            form{ 
                /* width: 80%;
                padding: 0; */
            }
    }
    </style>

    <?php
        include("database.php");

    if (isset($_GET["code"])) {
      if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE code='{$_GET['code']}'"))) {
        if (isset($_POST["button"])) {
            $password = $_POST["password"];
            $passwordRepeat = $_POST["repeat_password"];
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        if (empty($password) OR empty($passwordRepeat)) {
            echo "<div class='alert alert-danger'>Both fields are required</div>";   
        }else if(strlen($password)<8 || !preg_match("#[0-9]+#",$password)){ 
            echo "<div class='alert alert-danger'>Password must 8 characters and one number</div>";
        }else if($password != $passwordRepeat){ 
            echo "<div class='alert alert-danger'>Password does not match</div>";
        }
        else {
        $sql = "UPDATE users SET password = '$passwordHash' WHERE code = '{$_GET['code']}'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo "<div class='alert alert-success'>Your password has been updated successfully.</div>";
        } else {
            die("Something went wrong");
        }
    } 
        }  
      }
    } 
    ?> 

    <div class="d-flex justify-content-center">
        <div class="d-inline">
    <img src="ila-logo.png" width="500px"><br>
        <form action="" method="post"> 
            <div class="position-relative">
            <input type="password" onpaste="return false;" oncopy="return false;" class="form-control" id="password" name="password" placeholder="Password:">
            <i class="fa-solid fa-eye" aria-hidden="true" id="show_password"></i>
            </div> 
            <br>
            <input type="text" onpaste="return false;" oncopy="return false;" class="form-control" name="repeat_password" placeholder="Repeat Password">
             <br>
             <div class="d-flex justify-content-center">
            <button type="submit" class="btn btn-primary" name="button" id="button">Save</button>
            </div>
        </form>
        </div>
    </div>
    
    <script>
    const show_password = document.getElementById("show_password");
   const password = document.getElementById("password");

   show_password.addEventListener("click", () => {
       password.type = password.type === "password" ? "text" : "password";
       show_password.classList.toggle("fa-eye-slash");
   });
</script>
</body>
</html>