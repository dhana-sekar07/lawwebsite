<?php 
require_once('database.php'); 

$value = $_POST['value'];
$query = mysqli_query($conn, "UPDATE pagelimit SET count = '$value' WHERE id = 1");

if ($query) {
  $q = mysqli_query($conn, "SELECT * FROM pagelimit");
  $data = mysqli_fetch_assoc($q);
  echo $data['count'];
}

mysqli_close($conn);
?> 