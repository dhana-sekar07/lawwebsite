<?php
include("database.php");
if(isset($_POST['edit_id'])){
    $id=$_POST['edit_id'];
    $sql="SELECT * FROM users WHERE id='$id' ";
    $result=mysqli_query($conn, $sql);
    while($row=mysqli_fetch_array($result)){
        $id=$row['id'];
        $name=$row['name'];
        $email=$row['email'];

    }
}
?>

<input type="hidden" class="form-control" name="edit_id" id="edit_id" value="<?php echo $id ?>">
 
<label>User Name:</label>
<input type="text" onpaste="return false;" oncopy="return false;" class="form-control" name="name" value="<?php echo $name ?>"><br>

<label>Email:</label>
<input type="email" onpaste="return false;" oncopy="return false;" class="form-control" name="email" value="<?php echo $email ?>">