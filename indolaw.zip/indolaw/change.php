<?php
require_once('database.php');
$query=mysqli_query($conn, "UPDATE users SET status='".$_POST['value']."' WHERE id='".$_POST['id']."' ");
if($query) {
    $q=mysqli_query($conn, "SELECT * FROM users WHERE id='".$_POST['id']."' ");
    $data=mysqli_fetch_assoc($q);
    echo $data['$status'];
}
?>