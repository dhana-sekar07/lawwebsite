<?php
session_start();
if(isset($_SESSION["user"])){
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up page</title> 
    <?php include "head.php"; ?>
</head>

<body>
    <style>
        body{
          display: flex;
          justify-content: center;
          padding: 20px;
          background: #e6e6e6;
        }
        .container{  
            padding: 0 50px 20px 50px; 
            box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;
        }
        .form-group{
            margin-bottom: 30px;
        }
        i{
          position: absolute !important;
          right: 20px;
          top: 20%; 
          font-size: 20px;
          cursor: pointer;
         }
         @media(max-width:768px){ 
            body{
                padding: 0 !important;
            }
         }
    </style>
 
 <div class="inline">
 <div class="container">
        <?php
        if (isset($_POST["submit"])) {
            $name = $_POST["name"];
            $mobile_no = $_POST["mobile_no"];
            $email = $_POST["email"];
            $password = base64_encode($_POST["password"]);
            $passwordRepeat = base64_encode($_POST["repeat_password"]);
            $errors = array();

            require_once "database.php";
            if(empty($name) OR empty($mobile_no) OR empty($email) OR empty($password) OR empty($passwordRepeat)){
                array_push($errors, "All fields are required");
            }
            else if(!preg_match("/^[a-zA-z]*$/",$name)){
                array_push($errors, "Only letters and white space allowed in name");
            }
            else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                array_push($errors, "Email is not valid");
            }
            elseif(strlen($mobile_no)>10){
                array_push($errors, "mobile number must be in 10 digits only");
            }
            else if(strlen($password)<8 || !preg_match("#[0-9]+#",$password)){
                array_push($errors, "Password must 8 characters and one number");
            }
            else if($password!==$passwordRepeat){
                array_push($errors, "Password does not match");
            }else if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email='{$email}'")) > 0){ 
                array_push($errors, "Email already exists!");
            } 
            if (count($errors)>0) {
                foreach ($errors as $error) {
                    echo "<div class='alert alert-danger'>$error</div>";
                }
            }else {
                $sql = "INSERT INTO users (name, mobile_no, email, password) VALUES( '$name', '$mobile_no', '$email', '$password')";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    echo "<div class='alert alert-success'>You are registered successfully.</div>";
                }else {
                    die("Something went wrong");
                }
              }
           }
        ?>
        <div class="d-flex justify-content-center">
              <img src="ila-logo.png" width="300px">
        </div>
        <div class="d-flex justify-content-center">
            <h4 style="color: blue;font-family: 'Protest Guerrilla', sans-serif;">CREATE ACCOUNT</h4>
        </div><br>
        <form action="register.php" method="post"> 
            <input type="text" onpaste="return false;" oncopy="return false;" class="form-control" name="name" placeholder="Name:">
              <br> 
            <input type="number" onpaste="return false;" oncopy="return false;" class="form-control" name="mobile_no" placeholder="Mobile Number:">
              <br>
            <input type="email" onpaste="return false;" oncopy="return false;" class="form-control" name="email" placeholder="Email:">
              <br>
            <div class="position-relative">
            <input type="password" onpaste="return false;" oncopy="return false;" id="password" class="form-control" name="password" placeholder="Password:">
            <i class="fa-solid fa-eye" aria-hidden="true" id="show_password"></i>
            </div>
            <br>
            <input type="text" onpaste="return false;" oncopy="return false;" class="form-control" name="repeat_password" placeholder="Repeat Password:">
              <br>
            <div class="d-flex justify-content-center">
                <input type="submit" class="btn btn-primary" value="Register" name="submit">
            </div>
        </form>
    </div>
    </div>

    <script>
    const show_password = document.getElementById("show_password");
   const password = document.getElementById("password");

   show_password.addEventListener("click", () => {
       password.type = password.type === "password" ? "text" : "password";
       show_password.classList.toggle("fa-eye-slash");
   });
</script>
</body>
</html>