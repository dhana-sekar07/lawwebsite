<?php

include("database.php");

$del_id=$_POST['del_id'];

$sql="delete from users where id='".$del_id."' ";
$result=mysqli_query($conn, $sql);

?>