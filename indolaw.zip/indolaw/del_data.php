<?php
include("database.php");
if(isset($_POST['del_id'])){
    $id=$_POST['del_id'];
    $sql="SELECT * FROM users WHERE id='$id'";
    $result=mysqli_query($conn, $sql);
    while($row=mysqli_fetch_array($result)){
        $id=$row['id'];
    }
}
?>

<input type="hidden" class="form-control" name="del_id" id="del_id" value="<?php echo $id ?>">
<p>Do you want to delete this record? Not undo!</p>