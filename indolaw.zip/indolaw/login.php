<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title> 
    <?php include "head.php"; ?> 
</head>

<body>

 <!-- css starts -->
    <style> 
body{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-image: url('joanna-kosinska-1_CMoFsPfso-unsplash.jpg'); 
    background-repeat: no-repeat;
    background-size: cover;
    }

form{
    width: 420px;
    background: transparent;
    color: #fff;
    border-radius: 10px;
    padding: 30px 40px !important;
}

.input-box{
    position: relative; 
    height: 50px; 
}

 input{
    width: 100%;
    height: 50px;
    background: transparent;
    border: 2px solid rgba(255, 255, 255, .2);
    border-radius: 40px;
    color: #fff;
    padding: 20px 45px 20px 20px;
}

input::placeholder{
    color: #fff;
}

i{
    position: absolute !important;
    right: 20px;
    top: 20%; 
    font-size: 20px;
    cursor: pointer;
} 

.btn-dark{
    width: 100%;  
    border-radius: 40px; 
} 

a{
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}

a:hover{
    text-decoration: underline;
}

@media(max-width:768px){
    body{ 
        width: 80% !important;
    }
    form{
        width: 90% !important; 
        margin-left: 50px !important;
    } 
}
    </style>
<!-- css ends -->
 
<div class="d-inline">
        <?php
        if(isset($_POST["login"])){
            $email = $_POST["email"];
            $password =base64_encode($_POST["password"]); 
             require_once "database.php";
             $sql = "SELECT * FROM users WHERE email = '$email'";
             $result = mysqli_query($conn, $sql);
            
             if(mysqli_num_rows($result)>0){
                    $row = mysqli_fetch_assoc($result);
                    $admin = $row["name"];    

                    if (is_array($row)){
                    $_SESSION["user_id"] = $row['id'];
                    $_SESSION["name"] = $row['name'];
                    } 
                    if (empty($email) || empty($password)){
                        echo"<div class='alert alert-danger'>Both fields are required!</div>";
                    }else if($email != $row["email"] || $password != $row["password"]){
                        echo"<div class='alert alert-danger'>Email or password is invalid!</div>";
                    } else if($row["status"]==''){
                         echo"<div class='alert alert-danger'>Your Request is Pending!</div>";
                    }else if($row["status"]==0){
                         $_SESSION["user"]=$admin;
                         header("location:index.php");
                    }else if($row["status"]==1){
                         $_SESSION["admin"]=$admin;
                         header("location:adminhome.php?page_nr=1");
                    }else if($row["status"]==2){
                        $_SESSION["super_admin"]=$admin;
                        header("location:adminhome.php?page_nr=1");
                   } 
                }
              }
           ?>

        <!-- form starts --> 
        <form action="" method="post">

              <img src="ila-logo.png" width="300px"> 
            <div class="position-relative">
            <input type="email" onpaste="return false;" oncopy="return false;" placeholder="Enter email" name="email">
            <i class="fa-solid fa-envelope"></i><br><br>
            </div>
 
            <div class="position-relative">
            <input type="password" onpaste="return false;" id="password" oncopy="return false;" placeholder="Enter Password" name="password">
             <i class="fa-solid fa-eye" aria-hidden="true" id="show_password"></i><br><br>
            </div>

           <div class="d-flex justify-content-center">
           <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Forgot Password?
           </button> 
           </div><br>

           <button type="submit" name="login" class="btn btn-dark"><b>Login</b></button><br><br>

           <div class="register-link text-center">
            <p>Don't have an account?
                <a href="register.php">Register</a>
            </p>
           </div>
        </form>
        </div>
        <!-- form ends --> 

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Enter Your Mail:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php
        // php mailer code starts
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\Exception; 
        
        require 'phpmailer/src/Exception.php';
        require 'phpmailer/src/PHPMailer.php';
        require 'phpmailer/src/SMTP.php';

        if (isset($_POST["submit"])) {
            require_once "database.php";
            $gmail = mysqli_real_escape_string($conn, $_POST['gmail']); 
            $code = mysqli_real_escape_string($conn, md5(rand()));
            $query = mysqli_query($conn, "UPDATE users SET code='{$code}' WHERE email='{$gmail}'");

            if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email='{$gmail}'")) > 0) {    
            if (empty($gmail)) {
                echo "<div class='alert alert-danger'>Kindly Enter Your Email!</div>";
            }else if (!filter_var($gmail, FILTER_VALIDATE_EMAIL)) {
                echo "<div class='alert alert-danger'>Email is not valid!</div>"; 
            } else if($query){
                 // php mailer code starts
          $mail = new PHPMailer(true);

          $mail->isSMTP();
          $mail->Host = 'smtp.gmail.com';
          $mail->SMTPAuth = true;
          $mail->Username = ''; // your gmail
          $mail->Password = ''; // your gmail app password
          $mail->SMTPSecure = 'ssl';
          $mail->Port = 465;
      
          $mail->setFrom(''); // your gmail
      
          $mail->addAddress($_POST["gmail"]);
      
          $mail->isHTML(true);
      
          $mail->Subject = 'no reply';
          $mail->Body = '<b>Here is the verification Link :</b><br><br>
                         <a href="http://localhost/indolaw/setpassword.php?code='.$code.'">Click Here</a>'; 
          $mail->send();
      
          echo "<script>
                alert('A verification mail is sent to your mail');
                </script>"; 
                // php mailer code ends
            }
           } else {
            echo "<div class='alert alert-danger'>Email does not exits!</div>";
           }
        }
         ?>
         <form action="" method="post" class="m-0 p-0 w-100">
            <input type="email" name="gmail" class="form-control">
      </div>
      <div class="modal-footer"> 
        <button type="submit" name="submit" class="btn btn-primary">VERIFY</button>
      </div>
      </form>
    </div>
  </div>
</div>

<script>
    const show_password = document.getElementById("show_password");
   const password = document.getElementById("password");

   show_password.addEventListener("click", () => {
       password.type = password.type === "password" ? "text" : "password";
       show_password.classList.toggle("fa-eye-slash");
   });
</script>

</body>
</html>