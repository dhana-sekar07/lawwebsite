<?php
session_start();
if(!isset($_SESSION["admin"]) && !isset($_SESSION["super_admin"])) { 
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Message page</title>
<?php include "head.php"; ?>

<body>
    <style>
        *{ 
            box-sizing: border-box !important;
        }
		.main-content{
			width: 80%;
		}
		@media(max-width:768px){
            .main-content{
                width: 100%;
            }
        }
    </style>

<?php include "header.php"; ?>
<div class="main-content px-5 float-end" style="margin-top: 100px !important;">
<?php  
if (isset($_POST['submit'])){ 
    $selectedRows = $_POST["selected_rows"]; 
        date_default_timezone_set('Asia/Kolkata'); 
         $time = date("g:i A");
         $date = date("d/m/y");  
         $message = $_POST["message"];
    
         if (empty($selectedRows)) {
          echo "<div class='alert alert-danger'>No row selected!";
         }else if (empty($message)){
          echo "<div class='alert alert-danger'>message is required!";
         } else {
      require_once "database.php";
      $insertqry = "INSERT INTO message (date, time, message, mobile_no) VALUES ('{$date}','{$time}','{$message}','{$selectedRows}')";
      if ($conn->query($insertqry)) { 
        echo '<script>window.location.href = "https://web.whatsapp.com/send?phone='.$key.'&text='.$message.'&source=&data=";
        </script>';
      } 
  } 
} 

$count_result = mysqli_query($conn, "SELECT * FROM pagelimit");
$row = mysqli_fetch_assoc($count_result);
$limit = $row['count'];
$page = isset($_GET['page_nr']) ? $_GET['page_nr'] : 1;
$start = ($page - 1) * $limit;
$record = mysqli_query($conn,"SELECT * FROM users");
$numberofrows = $record->num_rows;
$pages = ceil($numberofrows/$limit);
$current_page = $_GET['page_nr']; 
$result = mysqli_query($conn, "SELECT * FROM users LIMIT $start , $limit");
?>

<b class="float-start">Note : please login whatsapp in new tab, before sending message.</b>

<div class="float-end">
<label style="color: #002b80;"><b>show</b></label>
<select name="" id="page-record"> 
  <option disabled="disabled" selected="selected"><?php echo $limit;?></option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
  <label style="color: #002b80;"><b>entries</b></label>
  </div><br>
<hr>
<form action="" method="post">
<div class="row mt-4">
<div class="col-lg-5 col-md-12">
    <!-- start table -->
    <table class="table table-striped table-hover float-end">
             <tr>  
                <th>Select</th>
                <th>S.No</th>
                <th>User Name</th> 
                <th>View Message</th> 
            </tr>

            <?php 
            $i = 1; 
            while($row = mysqli_fetch_assoc($result)) {
            ?>

             <!-- fetching row from column -->
            <tr>  
                <td class="mobile_no d-none"><?php echo $row['mobile_no']; ?></td>
                <td><?php echo "<input type='checkbox' name='selected_rows[]' value='{$row["mobile_no"]}'>"; ?></td>
                <td><?php echo ++$start; ?></td> 
                <td><?php echo $row['name']; ?></td>  
                <td><button type="button" class="btn btn-secondary btn-sm view" data-bs-toggle="modal" data-bs-target="#view">
                      View
                    </button></td> 
            </tr>
            <?php } ?> 
        </table>
        </div>
        
  <div class="col-lg-7 col-md-12">
<textarea name="message" rows="15" class="form-control bg-secondary text-white"></textarea>
<div class="d-flex justify-content-center mt-3">
<?php echo"<button type='submit' class='btn btn-secondary btn-sm' name='submit'>
            Send</button>"; ?>
  </div>
</div>
        <!-- end table -->
        <!-- page navigation -->
							<div class="d-flex justify-content-center">
<nav aria-label="Page navigation example">
    <ul class="pagination">
        <li class="page-item">
            <?php if ($current_page > 1) { ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page - 1 ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } ?>
        </li>
        <?php for ($counter = 1; $counter <= $pages; $counter++) { ?>
            <li class="page-item"><a class="page-link" href="?page_nr=<?php echo $counter ?>"><?php echo $counter ?></a></li>
        <?php } ?>
        <li class="page-item">
            <?php
            if ($current_page < $pages) {
                ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page + 1 ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } ?>
        </li>
    </ul>
</nav>
</div>
      <!-- page navigation ends -->
        </div>
      </form>
</div>

<!-- message view modal -->
<div class="modal fade" id="view" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_data">
       
      </div> 
    </div>
  </div>
</div>
<!-- end message view modal -->
 
<script>
//  script for page limit 
$(document).ready(function() {
  $('#page-record').on('change', function() {
    var selectedValue = $(this).val();
    setpagelimit(selectedValue);
  });
});

function setpagelimit(value) {
    event.preventDefault(); 
    $.ajax({
        type:'post',
        url:'setlimit.php',
        data:{value:value},

        success:function(result){
            console.log("Server response:",result);
            location.reload(); 
         },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX request failed:", textStatus, errorThrown);
        }
    });
} 
// end script for page limit

  //script for select only one check box  
$("input:checkbox").on('click', function() { 
   $box = $(this);
  if ($box.is(":checked")) { 
    var group = "input:checkbox[name='" + $box.attr("name") + "']"; 
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
}); 
 //end script for select only one check box 

// script for view reminder
$(document).ready(function(){
$('.view').click(function(e) { 
          e.preventDefault();
        var mobile_no =  $(this).closest('tr').find('.mobile_no').text();

          $.ajax({
            type:'post',
            url:'view_message.php',
            data:{
                  'click_view_btn':true,
                  'mobile_no':mobile_no,
                }, 
            success:function(response){ 
                $('#view_data').html(response);
                $('#view').modal('show');
            }
        });
        });
});
   // end view reminder script 
</script>

</body>
</html> 