<table class="table table-striped table-hover">
							<tr>
								<th>S.No</th>
								<th>Client Name</th>
								<th>Case Type</th>
								<th>Case</th>
								<th>Hearing</th>
								<th>Time</th>  
								<th>Actions</th>
							</tr> 
      <?php    
              if (isset($_POST['click_view_btn'])) {
                      require_once('database.php');  

                      $user_id = $_POST['user_id'];
                      $sql = "SELECT * FROM cases WHERE user_id=$user_id ORDER BY date ASC";
                      $res = $conn->query($sql);
                      $i=0;
 
                    while($row=$res->fetch_assoc()){
                      $i++;
                      $formatted_date = date('d/m/y', strtotime($row["date"]));
                      $formatted_time = date('g:i A', strtotime($row["time"]));
                        echo "
                              <tr>
											            <td>{$i}</td>
                                  <td>{$row["clientname"]}</td>
                                  <td>{$row["casetype"]}</td>
											            <td>{$row["cases"]}</td> 
                                  <td>{$formatted_date}</td>
                                  <td>{$formatted_time}</td>
											            <td>
                                  <button class='btn btn-secondary btn-sm edit_case' id='{$row["id"]}' data-bs-dismiss='modal'>
                                     <i class='fa-solid fa-pen'></i>
                                  </button>
                                  <a href='delete_cases.php?id={$row["id"]}' class='btn btn-sm btn-secondary' onclick='return confirm(\"Are You Sure ?\")'><i class='fa-solid fa-trash'></i></a></td>
										          </tr>";
                    }
              }
      ?> 
</table>

<!-- start edit case model -->
<div class="modal fade" id="editData" tabindex="-1" aria-labelledby="exampleModalLabelToggle2" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

        <!-- form starts -->
        <form action="#" method="post" id="updateForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Case</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body" id="info_update"> 
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="update">Update</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
      </form>
      <!-- form ends -->
      
    </div>
  </div>
</div>
<!-- end edit case model -->

<script>
	    // update script
$(document).ready(function(){
		$(document).on('click','.edit_case', function(){
        var edit_id=$(this).attr('id');
        $.ajax({
            url:'edit_case.php',
            type:'post',
            data:{edit_id:edit_id},
            success:function(data){
                $("#info_update").html(data);
                $("#editData").modal('show');
            }
        });
    });
    // end update script

    // save update script
    $(document).on('click', '#update', function(){
        $.ajax({
            url:'save_upd_case.php',
            type:'post',
            data:$("#updateForm").serialize(),
            success:function(data){
                $("#editData").modal('hide');
                location.reload();
            }
        });
    });
    // end save update script
});
</script> 