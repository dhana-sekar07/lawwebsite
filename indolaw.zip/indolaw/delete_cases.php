<?php 
	require("database.php");
	
	$sql="delete from cases where ID='{$_GET["id"]}'";
	if($conn->query($sql)){
		header("location:existingcases.php");
	}
?>