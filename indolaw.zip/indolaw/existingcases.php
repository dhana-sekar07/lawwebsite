<?php
session_start();
if(!isset($_SESSION["admin"]) && !isset($_SESSION["super_admin"])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Existing Cases page</title>
<?php include "head.php"; ?>
	<body>
		<style>
		*{ 
            box-sizing: border-box !important;
        }
		.main-content{
			width: 80%;
            margin-top: 100px !important;
		}
		@media(max-width:768px){
            .main-content{
                width: 100%;
            }
        }
		</style>
	<?php include "header.php";?> 
	<?php
			require_once "database.php";
			$user_id = $_SESSION['user_id']; 	
			$count_result = mysqli_query($conn, "SELECT * FROM pagelimit");
			$row = mysqli_fetch_assoc($count_result);
			$limit = $row['count'];
			$page = isset($_GET['page_nr']) ? $_GET['page_nr'] : 1;
			$start = ($page - 1) * $limit;
			$record = mysqli_query($conn,"SELECT * FROM cases WHERE status=''");
			$numberofrows = $record->num_rows;
			$pages = ceil($numberofrows/$limit);
			$current_page = $_GET['page_nr']; 

	if (isset($_GET['page_nr'])) {
		$current_page = $_GET['page_nr'];
		$start = ($current_page - 1) * $limit; 
		if (isset($_SESSION["super_admin"])){
			$sql = "SELECT * FROM cases WHERE status=''
			ORDER BY cases.date ASC  LIMIT $start, $limit";
		}else{
		$sql="SELECT * FROM cases 
		INNER JOIN users ON users.id=cases.user_id 
		WHERE users.id=$user_id AND cases.status=''
		ORDER BY cases.date ASC LIMIT $start, $limit";}
	 } else { 
		 if (isset($_SESSION["super_admin"])){
			$sql = "SELECT * FROM cases WHERE status=''
			ORDER BY cases.date ASC LIMIT $start, $limit";
		}else{
		$sql="SELECT * FROM cases 
		INNER JOIN users ON users.id=cases.user_id 
		WHERE users.id=$user_id AND cases.status=''
		ORDER BY cases.date ASC LIMIT $start, $limit";}
	  }

	$res=$conn->query($sql); 
	?>

		<div class="main-content px-5 float-end"> 
			<!-- Reminder button -->
			<div class="float-end">
					<label style="color: #002b80;"><b>show</b></label>
					<select name="" id="page-record"> 
					<option disabled="disabled" selected="selected"><?php echo $limit;?></option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					</select>
					<label style="color: #002b80;"><b>entries</b></label> 
			</div>
<button type="button" class="btn btn-info mb-2 float-start" data-bs-toggle="modal" data-bs-target="#exampleModal">
  <i class="fa-solid fa-plus"></i> Add cases
</button>
				<table class="table table-striped table-hover">
							<tr>
								<th>S.No</th>
								<th>Client Name</th>
								<th>Case Type</th>
								<th>Case</th>
								<th>Court Branch</th>
								<th>Hearing</th>
								<th>Time</th>  
								<th>Update case<br>status After<br>completed</th>
								<th>Actions</th>
							</tr> 
						<?php 
								if($res->num_rows>0){
									$i=0;
									while($row=$res->fetch_assoc()){ 
										$i++;
                                        $formatted_date = date('d/m/y', strtotime($row["date"]));
                                        $formatted_time = date('g:i A', strtotime($row["time"]));
										?>
									
										<tr>  
										    <td><?php echo ++$start; ?></td>
									<?php
											echo "
											<td>{$row["clientname"]}</td>
											<td>{$row["casetype"]}</td>
											<td>{$row["cases"]}</td>
											<td>{$row["courtbranch"]}</td>
                                            <td>{$formatted_date}</td>
                                            <td>{$formatted_time}</td> 
											<td><button type='button' class='btn btn-secondary btn-sm' onclick='active_inactive_user(1,{$row["id"]})'>completed</button></td>
											<td>
											  <button class='btn btn-secondary btn-sm edit_data' id='{$row["id"]}'>
											  <i class='fa-solid fa-pen'></i>
										      </button>
											  <a href='delete_cases.php?id={$row["id"]}' class='btn btn-sm btn-secondary' onclick='return confirm(\"Are You Sure ?\")'><i class='fa-solid fa-trash'></i></a> 
											</td>
										</tr>";
							    
									}
								}
							?>
					</table> 
					<!-- page navigation -->
					<div class="d-flex justify-content-center">
<nav aria-label="Page navigation example">
    <ul class="pagination">
        <li class="page-item">
            <?php if ($current_page > 1) { ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page - 1 ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } ?>
        </li>
        <?php for ($counter = 1; $counter <= $pages; $counter++) { ?>
            <li class="page-item"><a class="page-link" href="?page_nr=<?php echo $counter ?>"><?php echo $counter ?></a></li>
        <?php } ?>
        <li class="page-item">
            <?php
            if ($current_page < $pages) {
                ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page + 1 ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } ?>
        </li>
    </ul>
</nav>
</div>
      <!-- page navigation ends -->
		</div>
		
<!-- Add case modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">ADD CASE</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
	  <?php 
						if(isset($_POST["reg"])){
							$clientname = $_POST["clientname"];
							$casetype = $_POST["casetype"];
							$case = $_POST["case"];
							$courtbranch = $_POST["courtbranch"]; 
							$date = $_POST["date"];
							$time = $_POST["time"];
							$user_id = $_SESSION['user_id'];

							require_once "database.php";
							$sql = "INSERT INTO cases (clientname, casetype, cases, courtbranch, date, time, user_id) VALUES 
							('{$clientname}','{$casetype}','{$case}','{$courtbranch}','{$date}','{$time}','{$user_id}')";

							if($conn->query($sql)){
								echo"<div class='alert alert-success'>Added Successfully</div>";
							}else{
								echo"<div class='alert alert-danger'>Failed Try Again</div>";
							}
						}
					?>
					<form action="" method="post">
							<label><b>Client Name:</b></label>
							<input type="text" class="form-control"  name="clientname" required><br>
							
							<label><b>Case Type:</b></label>
							<input type="text" class="form-control"  name="casetype" required><br>

                            <label><b>Case:</b></label>
                            <textarea class="form-control" name="case"></textarea> <br>
							
							<label><b>Court Branch:</b></label>
							<input type="text" class="form-control"  name="courtbranch" required><br>

							<label><b>Hearing:</b></label>
							<input type="date" class="form-control"  name="date" required><br>
 
                             <label><b>Time:</b></label>
							 <input type="time" class="form-control" name="time" required><br>

		                    <input type="submit" name="reg" value="Save" class="btn btn-primary"> 
                            <button type="button" class="btn btn-secondary float-end" data-bs-dismiss="modal">Close</button> 
					</form>
      </div> 
	</div>
  </div>
</div>
<!-- end add case modal -->

<!-- start edit model -->
<div class="modal fade" id="editData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

        <!-- form starts -->
        <form action="#" method="post" id="updateForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Case</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body" id="info_update">
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="update">Update</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
      </form>
      <!-- form ends -->
      
    </div>
  </div>
</div>
<!-- end edit model -->

<script>

//  script for page limit 
$(document).ready(function() {
  $('#page-record').on('change', function() {
    var selectedValue = $(this).val();
    setpagelimit(selectedValue);
  });
});

function setpagelimit(value) {
    event.preventDefault(); 
    $.ajax({
        type:'post',
        url:'setlimit.php',
        data:{value:value},

        success:function(result){
            console.log("Server response:",result);
            location.reload(); 
         },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX request failed:", textStatus, errorThrown);
        }
    });
} 
// end script for page limit

$(document).ready(function(){
	    // update script
		$(document).on('click','.edit_data', function(){
        var edit_id=$(this).attr('id');
        $.ajax({
            url:'edit_case.php',
            type:'post',
            data:{edit_id:edit_id},
            success:function(data){
                $("#info_update").html(data);
                $("#editData").modal('show');
            }
        });
    });
    // end update script

    // save update script
    $(document).on('click', '#update', function(){
        $.ajax({
            url:'save_upd_case.php',
            type:'post',
            data:$("#updateForm").serialize(),
            success:function(data){
                $("#editData").modal('hide');
                location.reload();
            }
        });
    });
    // end save update script
});

//  script for change status
function active_inactive_user(value, id) {
    event.preventDefault(); 
    $.ajax({
        type:'post',
        url:'changecasestatus.php',
        data:{value:value,id:id},

        success:function(result){
            console.log("Server response:",result);
            location.reload(); 
         },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX request failed:", textStatus, errorThrown);
        }
    });
} 
//  end script for change status
</script>

	</body>
</html>