<?php
include("database.php");
        $edit_id = $_POST['edit_id'];
        $clientname = $_POST['clientname'];
        $casetype = $_POST['casetype']; 
        $case = $_POST['case'];
        $courtbranch = $_POST['courtbranch'];
        $date = $_POST['date'];
        $time = $_POST['time'];

$sql="UPDATE cases SET clientname='".$clientname."', casetype='".$casetype."', cases='".$case."', courtbranch='".$courtbranch."', date='".$date."', time='".$time."' WHERE id='".$edit_id."' ";
$result=mysqli_query($conn, $sql);
?>