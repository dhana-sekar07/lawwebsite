<?php
include("database.php");
$edit_id=$_POST['edit_id'];
$name=$_POST['name'];
$email=$_POST['email'];

if(empty($name) OR empty($email)) { 
    echo "<div class='alert alert-danger'>All fields are required</div>";
}
else if(!preg_match("/^[a-zA-z]*$/",$name)){ 
    echo "<div class='alert alert-danger'>Only letters and white space allowed in username</div>";
}
else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){ 
    echo "<div class='alert alert-danger'>Email is not valid</div>";
} else {
$sql="UPDATE users SET name='".$name."', email='".$email."' where id='".$edit_id."' ";
$result=mysqli_query($conn, $sql);
}
?>