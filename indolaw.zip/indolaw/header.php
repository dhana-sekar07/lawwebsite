<?php 
    require_once "database.php";
	$today=date("d-m-Y");
    $tomorrow = date("d-m-Y",strtotime("+1days")); 
    $second_day = date("d-m-Y",strtotime("+2days"));
    $third_day = date("d-m-Y",strtotime("+3days"));
    $fourth_day = date("d-m-Y",strtotime("+4days"));
    $future_task=[];
	$notifications=[];
    $user_id = $_SESSION['user_id'];

 	$sql="SELECT * FROM cases 
          INNER JOIN users ON users.id=cases.user_id
          WHERE DATE_FORMAT(date,'%d-%m-%Y')
          IN ('{$today}','{$tomorrow}','{$second_day}','{$third_day}','{$fourth_day}')
          AND users.id=$user_id
          ORDER BY cases.date DESC";

	$res=$conn->query($sql);
	if($res->num_rows>0){
		while($row=$res->fetch_assoc()){ 
            $date = date('d/m/y', strtotime($row["date"]));
            $time = date('g:i A', strtotime($row["time"]));
            $task_date = date("d-m-Y", strtotime($row["date"]));
            
            if ($task_date==$today){
			$notifications[]="<i class='fa fa-bell'></i> <b>Today's Hearing:</b><br> <b>Court Branch:</b> {$row["courtbranch"]}<br>
            <b>Court Time:</b> {$time}<br><b>Client name:</b> {$row["clientname"]}<br><b>Case:</b> {$row["cases"]}";
            } 
            if ($task_date != $today) {
            $future_task[]="<b>Hearing on:</b> {$date}<br><b>Court Time:</b> {$time}<br><b>Court branch:</b> {$row["courtbranch"]}<br><b>Client Name:</b> {$row["clientname"]}<br><b>Case:</b> {$row["cases"]}";
            } 
        }
	}
?>
    <style>
        /* css */
        *{ 
            box-sizing: border-box !important;
        }
        header{
            display: flex;
            justify-content: space-between;
            align-items: center; 
            width: 100%;
            position: fixed;
            z-index: 1;
            box-shadow: 0px 25px 20px -20px rgba(0, 0, 0, 0.45);
        }
        h1{
            margin: auto;
            text-align: center;
            color: #002b80; 
        }
        nav li{
            list-style: none;
        } 
        nav a{
            text-decoration: none;
            color: #002b80;
            font-size: 15px;
            font-weight: bolder; 
            padding: 10px; 
        }
        nav a:hover{
            color: #fff;
            background: #002b80; 
            border-radius: 20px;
        }
        nav p{
            font-size: 25px;
            font-weight: bolder;
        }
        .container-sm{
            position: fixed;
            float: left;
            width: 20%; 
            height: 100% !important; 
            box-shadow: 25px 0 20px -20px rgba(0, 0, 0, 0.45);
            margin-top: 80px !important;
        }
        .fa-bars{
            cursor: pointer;   
            color: #002b80;
        }
        .fa-bell{
            color: #002b80;
        }
        .user{
            width: 95%;
            height: auto;
            background: #002b80;
            border-radius: 20px;
        }
        @media(max-width:768px){
            .container-sm{
                display: none;
                width: 90% !important;
                z-index: 2;
                margin-left: 20px !important;
                margin-top: 60px !important; 
                border-radius: 20px;
            }
            h1{
                font-size: 15px !important;
            } 
            .fa-bars{
                margin: 20px !important;
            }
            .btn-danger{
                margin: 0 !important;
            }
        }
    </style>

     <!-- header -->  
     <header class="bg-dark-subtle">
     <i class="fa-solid fa-bars ms-5 fs-2" id="toggle-btn"></i>
        <h1 class="py-3" style="font-family: 'Protest Guerrilla', sans-serif;"><b>INDO LAW ASSOCIATES</b><span class="fs-4">-Dashboard</span></h1> 
     <div class="nav-item dropdown pe-4">
				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					<span class='fa fa-bell'>(<?php echo count($notifications);?>)</span>
				</a>
				<?php if(count($notifications)>0): ?>
					<div class="dropdown-menu dropdown-menu-right p-2" aria-labelledby="navbarDropdown">
						<?php foreach($notifications as $row):?>
							<div class="dropdown-item alert alert-success"><?php echo $row; ?></div>
						<?php endforeach;?>
					</div>
				<?php endif; ?>
     </div>
     
     </header>

     <!-- side nav bar -->
    <div class="container-sm bg-dark-subtle">
        <img src="ila-logo.png" width="250px"> 
           <div class="user my-3 text-center">
           <i class="fa-solid fa-user-circle text-white mt-1 fs-1"></i><br>
           <?php 
                $username = $_SESSION["name"];
              if (isset($_SESSION["super_admin"])) {
                 echo "<div class='text-white'><b>Welcome : $username<br></b><small>(Master Admin)</small></div>";
              }
              if (isset($_SESSION["admin"])) {
                 echo "<div class='text-white'><b>Welcome : $username<br></b><small>(Admin)</small></div>";
              }
           ?>
           </div>
            <nav>
              <ul> 
                <li><a href="adminhome.php?page_nr=1" class="pe-5"><i class="fa-solid fa-house"></i> Home</a></li>  

                <!-- dropdown menu -->
                <div class="dropdown">
                    <a class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-solid fa-scale-balanced"></i> Case History
                    </a>
                  <ul class="dropdown-menu alert alert-warning">
                     <li><a class="dropdown-item" href="existingcases.php?page_nr=1"><b><i class="fa-solid fa-gavel"></i> Existing Cases</b></a></li>
                     <li><a class="dropdown-item" href="completedcases.php?page_nr=1"><b><i class="fa-solid fa-list-check"></i> Completed Cases</b></a></li>
                  </ul>
               </div>
           <!-- dropdown menu ends -->

				<li><a href="message.php?page_nr=1" class="pe-5"><i class="fa-brands fa-square-whatsapp"></i> Message</a></li> 
              </ul>
            
            </nav>
            <div class="d-flex justify-content-center">
            <a href="logout.php" class="btn btn-danger btn-sm" style="margin-top: 75% !important;"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
            </div>
        </div> 
    
<script> 
  // script for toggle nav bar
$(document).ready(function(){
    $("#toggle-btn").click(function(){
      $(".container-sm").toggle();
      if($(".container-sm").css('display') == 'none'){
        $(".main-content").css('width', '100%');
      } else {
        $(".main-content").css('width', '80%');
      } 
    });
});
// end script for toggle nav bar
</script>