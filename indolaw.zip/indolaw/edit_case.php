<?php
include("database.php");
if(isset($_POST['edit_id'])){
    $id=$_POST['edit_id'];
    $sql="SELECT * FROM cases WHERE id='$id' ";
    $result=mysqli_query($conn, $sql);
    while($row=mysqli_fetch_array($result)){

        $id = $row['id'];
        $date = $row['date'];
        $time = $row['time']; 
        $case = $row['cases'];
        $courtbranch = $row['courtbranch'];
        $clientname = $row['clientname'];
        $casetype = $row['casetype'];

    }
}
?>

<input type="hidden" class="form-control" name="edit_id" id="edit_id" value="<?php echo $id ?>">

<label><b>Client Name:</b></label>
<input type="text" class="form-control" name="clientname" value="<?php echo $clientname ?>"><br>

<label><b>Case Type:</b></label>
<input type="text" class="form-control" name="casetype" value="<?php echo $casetype ?>"><br>

<label><b>Case:</b></label>
<textarea class="form-control" name="case"><?php echo $case ?></textarea><br>

<label><b>Court Branch:</b></label>
<input type="text" class="form-control" name="courtbranch" value="<?php echo $courtbranch ?>"><br>
 
<label><b>Yearing:</b></label>
<input type="date" class="form-control" name="date" value="<?php echo $date ?>"><br>
 
<label><b>Time:</b></label>
<input type="time" class="form-control" name="time" value="<?php echo $time ?>"><br>