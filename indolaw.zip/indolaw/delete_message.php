<?php 
	require("database.php");
	
	$sql="delete from message where ID='{$_GET["id"]}'";
	if($conn->query($sql)){
		header("location:message.php");
	}
?>