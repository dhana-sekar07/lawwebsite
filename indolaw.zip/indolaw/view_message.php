<table class="table table-striped table-hover">
							<tr>
								<th>S.No</th>
								<th>Date</th>
								<th>Time</th>
								<th>Message</th> 
								<th>Actions</th>
							</tr>   
      <?php    
              if (isset($_POST['click_view_btn'])) {
                  require_once("database.php");  
               $mobile_no = $_POST["mobile_no"];
               $result = mysqli_query($conn, "SELECT * FROM message WHERE mobile_no = '$mobile_no'"); 
               $i = 0;
                   while ($row = mysqli_fetch_assoc($result)){   
                      $i++; 
                        echo "
                              <tr>
				  <td>{$i}</td>
                                  <td>{$row["date"]}</td>
                                  <td>{$row["time"]}</td>
				  <td>{$row["message"]}</td> 
				 <td> 
                                  <a href='delete_message.php?id={$row["id"]}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are You Sure ?\")'>Delete</a>
                                 </td>
			    </tr>";
                       } 
                }
        ?> 
</table> 