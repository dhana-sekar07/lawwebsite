<?php
session_start();
if(!isset($_SESSION["admin"]) && !isset($_SESSION["super_admin"])){ 
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Completed Cases page</title>
<?php include "head.php"; ?>
	<body>
		<style>
		*{ 
            box-sizing: border-box !important;
        }
		.main-content{
			width: 80%;
            margin-top: 100px !important;
		}
		@media(max-width:768px){
            .main-content{
                width: 100%;
            }
        }
		</style>
	<?php include "header.php"; ?>
    <?php
    require_once "database.php";
        $user_id = $_SESSION['user_id'];  
        $count_result = mysqli_query($conn, "SELECT * FROM pagelimit");
        $row = mysqli_fetch_assoc($count_result);
        $limit = $row['count'];
        $page = isset($_GET['page_nr']) ? $_GET['page_nr'] : 1;
        $start = ($page - 1) * $limit;
        $record = mysqli_query($conn,"SELECT * FROM cases WHERE status=1");
        $numberofrows = $record->num_rows;
        $pages = ceil($numberofrows/$limit);
        $current_page = $_GET['page_nr']; 

    if (isset($_GET['page_nr'])) {
        $current_page = $_GET['page_nr'];
        $start = ($current_page - 1) * $limit; 
        if (isset($_SESSION["super_admin"])){
            $sql = "SELECT * FROM cases WHERE status=1
            ORDER BY cases.date ASC  LIMIT $start, $limit";
        }else{
        $sql="SELECT * FROM cases 
        INNER JOIN users ON users.id=cases.user_id 
        WHERE users.id=$user_id AND cases.status=1
        ORDER BY cases.date ASC LIMIT $start, $limit";}
     } else { 
         if (isset($_SESSION["super_admin"])){
            $sql = "SELECT * FROM cases WHERE status=1
            ORDER BY cases.date ASC LIMIT $start, $limit";
        }else{
        $sql="SELECT * FROM cases 
        INNER JOIN users ON users.id=cases.user_id 
        WHERE users.id=$user_id AND cases.status=1
        ORDER BY cases.date ASC LIMIT $start, $limit";}
      }

    $res=$conn->query($sql);
     ?> 

		<div class="main-content px-5 float-end"> 
            
            <label style="color: #002b80;"><b>show</b></label>
            <select name="" id="page-record"> 
            <option disabled="disabled" selected="selected"><?php echo $limit;?></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>
            <label style="color: #002b80;"><b>entries</b></label><br><br> 
				<table class="table table-striped table-hover">
							<tr>
								<th>S.No</th>
								<th>Client Name</th>
								<th>Case Type</th>
								<th>Case</th>
								<th>Court Branch</th>
								<th>Completed on</th> 
								<th>Actions</th>
							</tr> 
						<?php 
						        
								if($res->num_rows>0){ 
									while($row=$res->fetch_assoc()){ 
                                        $formatted_date = date('d/m/y', strtotime($row["date"])); 
										?>

										<tr> 
                                            <td><?php echo ++$start; ?></td>
                            <?php
                                            echo "
                                            <td>{$row["clientname"]}</td>
											<td>{$row["casetype"]}</td>
											<td>{$row["cases"]}</td>
											<td>{$row["courtbranch"]}</td>
                                            <td>{$formatted_date}</td> 
											<td>
											  <button class='btn btn-secondary btn-sm edit_data' id='{$row["id"]}'>
											  <i class='fa-solid fa-pen'></i>
										      </button>
											  <a href='delete_cases.php?id={$row["id"]}' class='btn btn-sm btn-secondary' onclick='return confirm(\"Are You Sure ?\")'><i class='fa-solid fa-trash'></i></a> 
											</td>
										</tr>";
							    
									}
								}
							?>
					</table> 
					        <!-- page navigation -->
							<div class="d-flex justify-content-center">
<nav aria-label="Page navigation example">
    <ul class="pagination">
        <li class="page-item">
            <?php if ($current_page > 1) { ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page - 1 ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } ?>
        </li>
        <?php for ($counter = 1; $counter <= $pages; $counter++) { ?>
            <li class="page-item"><a class="page-link" href="?page_nr=<?php echo $counter ?>"><?php echo $counter ?></a></li>
        <?php } ?>
        <li class="page-item">
            <?php
            if ($current_page < $pages) {
                ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page + 1 ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } ?>
        </li>
    </ul>
</nav>
</div>
      <!-- page navigation ends -->
		</div>

<!-- start edit model -->
<div class="modal fade" id="editData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

        <!-- form starts -->
        <form action="#" method="post" id="updateForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Case</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body" id="info_update">
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="update">Update</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
      </form>
      <!-- form ends -->
      
    </div>
  </div>
</div>
<!-- end edit model -->

<script>
//  script for page limit 
$(document).ready(function() {
  $('#page-record').on('change', function() {
    var selectedValue = $(this).val();
    setpagelimit(selectedValue);
  });
});

function setpagelimit(value) {
    event.preventDefault(); 
    $.ajax({
        type:'post',
        url:'setlimit.php',
        data:{value:value},

        success:function(result){
            console.log("Server response:",result);
            location.reload(); 
         },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX request failed:", textStatus, errorThrown);
        }
    });
} 
// end script for page limit

$(document).ready(function(){
	    // update script
		$(document).on('click','.edit_data', function(){
        var edit_id=$(this).attr('id');
        $.ajax({
            url:'edit_case.php',
            type:'post',
            data:{edit_id:edit_id},
            success:function(data){
                $("#info_update").html(data);
                $("#editData").modal('show');
            }
        });
    });
    // end update script

    // save update script
    $(document).on('click', '#update', function(){
        $.ajax({
            url:'save_upd_case.php',
            type:'post',
            data:$("#updateForm").serialize(),
            success:function(data){
                $("#editData").modal('hide');
                location.reload();
            }
        });
    });
    // end save update script
}); 
</script>

	</body>
</html>