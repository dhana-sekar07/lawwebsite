<?php
session_start();
if(!isset($_SESSION["admin"]) && !isset($_SESSION["super_admin"])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en" class="m-0 p-0">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Home Page</title>
<?php include "head.php"; ?>
<body>

    <style>
        /* css */ 
        *{ 
            box-sizing: border-box !important; 
        }
        .main-content{ 
            float: right;
            width: 80%;
            margin-top: 100px !important;
        } 
        h2{
          color: #002b80;
        }
        .box{ 
          border-radius: 20px; 
          box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;
          display: flex;
          justify-content: center;
          align-items: center;
          text-align: center;
        }
        @media(max-width:768px){
        *{
          margin: 0 !important;
          padding: 0 !important;
        }
        .main-content{
                width: 100% !important;
                position: absolute;
                z-index: -1;
        }
        .box{
          padding: 0 !important;
        }

    }
    </style>

    <?php include "header.php"; ?>    <!-- including header and slide navbar -->
   
    <div class="main-content px-5">  
      <div class="row my-4">
        <div class="col">
           <div class="box bg-dark-subtle py-5"> 
           <b><i class="fa-solid fa-users fs-1"></i><br>  
              <?php 
                 $users = "SELECT * FROM users WHERE status='0'";
                 $noofusers = mysqli_query($conn,$users); 
                  $users_count = mysqli_num_rows($noofusers);
                   echo "Users : $users_count";
              ?></b>
           </div>
        </div>
        <div class="col">
           <div class="box bg-secondary py-5"> 
             <b class="text-white"><i class="fa-solid fa-gavel fs-1"></i><br>  
               <?php
                     $user_id = $_SESSION['user_id'];
                 if (isset($_SESSION["super_admin"])) {
                      $existingcase = "SELECT * FROM cases WHERE status=''"; 
                 } else {
                     $existingcase =  "SELECT * FROM cases INNER JOIN users ON users.id=cases.user_id 
                                      WHERE users.id=$user_id AND cases.status=''";
                  }
                  $noofexistingcase = mysqli_query($conn,$existingcase); 
                  $existingcase_count = mysqli_num_rows($noofexistingcase);
                  echo "Existing case : $existingcase_count";
                 ?></b>
           </div>
        </div>
        <div class="col">
           <div class="box bg-dark-subtle py-5">
           <b class=""><i class="fa-solid fa-scale-balanced  fs-1"></i><br>  
               <?php
                 if (isset($_SESSION["super_admin"])) {
                 $completedcase = mysqli_query($conn, "SELECT * FROM cases WHERE status=1"); }
                 else {
                  $user_id = $_SESSION['user_id'];
                  $completedcase = mysqli_query($conn, "SELECT * FROM cases 
                  INNER JOIN users ON users.id=cases.user_id 
                  WHERE users.id=$user_id AND cases.status=1");
                }
                 $completedcase_count = mysqli_num_rows($completedcase);  
                 echo "Completed case : $completedcase_count"; ?></b>
           </div>
        </div>
        <?php if (isset($_SESSION["super_admin"])) { ?>
        <div class="col">
           <div class="box bg-secondary py-5">
             <b class="text-white"><i class="fa-solid fa-users-gear fs-1"></i><br>
             <?php
                 $employs = mysqli_query($conn, "SELECT * FROM users WHERE status=1");
                 $employs_count = mysqli_num_rows($employs);  
                 echo "Employs : $employs_count";
              ?></b>
           </div>
        </div>
        <?php } else { ?>
           <div class="col">
           <div class="box bg-secondary py-5">
             <b class="text-white"><i class="fa-solid fa-hand-holding-heart fs-1"></i><br>
             <?php
                 $request = mysqli_query($conn,"SELECT * FROM users WHERE status=''");
                 $request_count = mysqli_num_rows($request);  
                 echo "Request : $request_count";
              ?></b>
           </div>
        </div>
      <?php  } ?>
      </div>
 
      <?php 
            // connect database & table 
            require_once('database.php');
            $count_result = mysqli_query($conn, "SELECT * FROM pagelimit");
            $row = mysqli_fetch_assoc($count_result);
            $limit = $row['count'];
            $page = isset($_GET['page_nr']) ? $_GET['page_nr'] : 1;
            $start = ($page - 1) * $limit;
            $record = mysqli_query($conn,"SELECT * FROM users");
            $numberofrows = $record->num_rows;
            $pages = ceil($numberofrows/$limit);
            $current_page = $_GET['page_nr']; 
            $result = mysqli_query($conn, "SELECT * FROM users LIMIT $start , $limit"); 
      ?>

<div class="float-end ms-5">
  <label style="color: #002b80;"><b>show</b></label>
<select name="" id="page-record"> 
  <option disabled="disabled" selected="selected"><?php echo $limit;?></option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
  <label style="color: #002b80;"><b>entries</b></label> 
</div>

            <h2 class="float-start mb-3"><b>USERS & EMPLOYS:</b></h2>
            
            <!-- Button for add user --> 
<button type="button" class="btn btn-primary float-end mb-3" data-bs-toggle="modal" data-bs-target="#addData">
    <i class="fa-solid fa-user-plus"></i> Add User
</button><br> 

<!-- start table -->
        <table class="table table-light table-striped table-hover">
            <tr>
                <th>S.No</th>
                <th>Name</th>
                <th>Mail-ID</th>
                <?php if (isset($_SESSION["super_admin"])){
                    echo "<th>View cases</th>";
                } ?>
                <th>Status</th>
                <th>Allow/Block</th>
                <th>Actions</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)){
            ?>

             <!-- fetching row from column -->
            <tr>
                <td class="user_id d-none"><?php echo $row['id']; ?></td>
                <td><?php echo ++$start; ?></td> 
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['email']; ?></td>

                <!-- task view button for super admin -->
                <?php if (isset($_SESSION["super_admin"])){   
                  echo"
                    <td>
                     <button type='button' class='btn btn-secondary btn-sm view' data-bs-toggle='modal' data-bs-target='#view'>
                         View
                     </button>
                </td>";
                  } ?> 
                
                <!-- active & inactive button -->
                <td>
                    <?php if($row['status']==''){      
                        echo "Blocked!"; ?>

                <?php } else if($row['status']==1){ ?>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="active_inactive_user(0,<?php echo $row['id'];?>)">Employ</button>
                  
                <?php } else if($row['status']==0){ ?>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="active_inactive_user(1,<?php echo $row['id'];?>)">User</button>
                <?php } ?>
                </td>

                <!-- allow & block button -->
                <td>
                  <?php if ($row['status']=='') { ?>
                    <button class="btn btn-secondary btn-sm" onclick="active_inactive_user(0,<?php echo $row['id'];?>)">Allow</button>

                 <?php } else if ($row['status'] == 0 && 1) { ?>
                    <button class="btn btn-secondary btn-sm" onclick="active_inactive_user('',<?php echo $row['id'];?>)">Block</button> 
                    <?php } ?>
                  </td>

                <!-- delete & edit button -->
                <td> 
                <button class="btn btn-secondary btn-sm edit_data" id="<?php echo $row['id'] ?>">
                   <i class="fa-solid fa-pen"></i>
                </button>
 
                <button class="btn btn-secondary btn-sm del_data" id="<?php echo $row['id'] ?>">
                <i class="fa-solid fa-trash"></i></button> 
                </td>
            </tr>
            <?php } ?>
        </table>
        <!-- end table --> 
        
        <!-- page navigation -->
      <div class="d-flex justify-content-center">
<nav aria-label="Page navigation example">
    <ul class="pagination">
        <li class="page-item">
            <?php if ($current_page > 1) { ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page - 1 ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            <?php } ?>
        </li>
        <?php for ($counter = 1; $counter <= $pages; $counter++) { ?>
            <li class="page-item"><a class="page-link" href="?page_nr=<?php echo $counter ?>"><?php echo $counter ?></a></li>
        <?php } ?>
        <li class="page-item">
            <?php
            if ($current_page < $pages) {
                ?>
                <a class="page-link" href="?page_nr=<?php echo $current_page + 1 ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } else { ?>
                <a class="page-link" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            <?php } ?>
        </li>
    </ul>
</nav>
</div>
      <!-- page navigation ends -->
        
    </div> 

<!-- start add user model -->
<div class="modal fade" id="addData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

        <!-- form starts -->
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">  
        <?php          
        // php mailer code starts
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\Exception; 
        
        require 'phpmailer/src/Exception.php';
        require 'phpmailer/src/PHPMailer.php';
        require 'phpmailer/src/SMTP.php';

        // insert user in data base code starts
        if (isset($_POST["button"])) {

          $name = $_POST["name"];
          $mobile_no = $_POST["mobile_no"];
          $email = mysqli_real_escape_string($conn, $_POST['email']);
          $code = mysqli_real_escape_string($conn, md5(rand()));

          $errors = array();
  
          if(empty($name) OR empty($mobile_no) OR empty($email)) {
              array_push($errors, "All fields are required");
          }
          else if(!preg_match("/^[a-zA-z]*$/",$name)){
              array_push($errors, "Only letters and white space allowed in username");
          }
          elseif(strlen($mobile_no)>10){
              array_push($errors, "mobile number must be in 10 digits only");
          }
          else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
              array_push($errors, "Email is not valid");
          }
          else if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email='{$email}'")) > 0){
            array_push($errors, "Email already exists!");
          } 
           if (count($errors)>0) {
              foreach ($errors as $error) {
                  echo "<div class='alert alert-danger'>$error</div>";
              }
          } 
          else {
                  $sql = "INSERT INTO users (name, mobile_no, email,code) VALUES( '$name', '$mobile_no', '$email', '$code')";
                  $result = mysqli_query($conn, $sql);
          if ($result) { 
                   echo "<div class='alert alert-success'>Added successfully</div>";
      
            // php mailer code starts
          $mail = new PHPMailer(true);

          $mail->isSMTP();
          $mail->Host = 'smtp.gmail.com';
          $mail->SMTPAuth = true;
          $mail->Username = ''; // your gmail
          $mail->Password = ''; // your gmail app password
          $mail->SMTPSecure = 'ssl';
          $mail->Port = 465;
      
          $mail->setFrom(''); // your gmail
      
          $mail->addAddress($_POST["email"]);
      
          $mail->isHTML(true);
      
          $mail->Subject = 'no reply';
          $mail->Body = '
          Dear '.$name.',<br><br> 
          We are thrilled to inform you that you have been added to Indo Law Associates user login portal.<br>
          This means that you can now access our services and features through a secure and convenient login process.<br>
          To ensure the security of your account and data,<br>
          <b>we kindly request you to set your password by clicking on the below link:</b><br><br>
          
          <a href="http://localhost/indolaw/setpassword.php?code='.$code.'">Click Here</a><br><br> 
          
          Best regards,<br><br>
           
          INDO LAW ASSOCIATES<br>
          mail: info@indolawassociates.com<br>
          8190963000<br>
          8940383000<br>
          url: indolawassociates.com'; 

          $mail->send();
      
          echo "<script>
                alert('Added Successfully,a gmail is sent to the this new user to set their password in the secure way');
                </script>"; 
                // php mailer code ends
                  }else {
                      die("Something went wrong");
                  } 
            // insert user in data base code ends
        }
            } 
        ?>

  <form action="" method="post">
             <input type="text" onpaste="return false;" oncopy="return false;" class="form-control" name="name" placeholder="Name:">
             <br> 

            <input type="number" onpaste="return false;" oncopy="return false;" class="form-control" name="mobile_no" placeholder="Mobile Number:">
            <br>

            <input type="email" onpaste="return false;" oncopy="return false;" class="form-control" name="email" placeholder="Email:">
             <br>
          </div>

      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" name="button" id="button">Save</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
  </form>
      <!-- form ends -->
    </div>
  </div>
</div>
<!-- end add user model -->

<!-- start edit model -->
<div class="modal fade" id="editData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

        <!-- form starts -->
        <form action="#" method="post" id="updateForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body" id="info_update">
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="update">Update</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
      </form>
      <!-- form ends -->
      
    </div>
  </div>
</div>
<!-- end edit model -->

<!-- start delete model -->
<div class="modal fade" id="delData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

        <!-- form starts -->
        <form action="#" method="post" id="delForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Delete User</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body" id="info_del">
       
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="del">Delete</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
      </form>
      <!-- form ends -->
      
    </div>
  </div>
</div>
<!-- end delete model -->

<!-- Modal case view for super admin -->
    <div class="modal fade" id="view" tabindex="-1" aria-labelledby="exampleModalLabelToggle" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="view_data">  
      </div> 
    </div>
  </div>
</div>
<!-- End of modal case view -->
 
<script>
//  script for page limit 
$(document).ready(function() {
  $('#page-record').on('change', function() {
    var selectedValue = $(this).val();
    setpagelimit(selectedValue);
  });
});

function setpagelimit(value) {
    event.preventDefault(); 
    $.ajax({
        type:'post',
        url:'setlimit.php',
        data:{value:value},

        success:function(result){
            console.log("Server response:",result);
            location.reload();
         },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX request failed:", textStatus, errorThrown);
        }
    });
} 
// end script for page limit

//  script for toast 
  <?php foreach ($future_task as $row): ?>
    toastr.options = {
      timeOut: 0,
      extendedTimeOut: 0
    };
    toastr.info('<button class="btn btn-light btn-sm float-end"><i class="fa-solid fa-xmark"></i></button><?php echo $row; ?>');
  <?php endforeach; ?> 
// end toast script
 
//  script for change status
function active_inactive_user(value, id) {
    event.preventDefault(); 
    $.ajax({
        type:'post',
        url:'change.php',
        data:{value:value,id:id},

        success:function(result){
            console.log("Server response:",result);
            location.reload(); 
         },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX request failed:", textStatus, errorThrown);
        }
    });
}
// end script for change status
  
    // edit script
$(document).ready(function(){
    $(document).on('click','.edit_data', function(){
        var edit_id=$(this).attr('id');
        $.ajax({
            url:'edit_user.php',
            type:'post',
            data:{edit_id:edit_id},
            success:function(data){
                $("#info_update").html(data);
                $("#editData").modal('show');
            }
        });
    });
    // end edit script

    // save edit script
    $(document).on('click', '#update', function(){
        $.ajax({
            url:'save_upd_user.php',
            type:'post',
            data:$("#updateForm").serialize(),
            success:function(data){
                $("#editData").modal('hide');
                location.reload();
            }
        });
    });
    // end save edit script

    // delete user script
    $(document).on('click','.del_data', function(){
        var del_id=$(this).attr('id');
        $.ajax({
            url:'del_data.php',
            type:'post',
            data:{del_id:del_id},
            success:function(data){
                $("#info_del").html(data);
                $("#delData").modal('show');
            }
        });
    });

    $(document).on('click', '#del', function(){
        $.ajax({
            url:'save_del.php',
            type:'post',
            data:$("#delForm").serialize(),
            success:function(data){
                $("#delData").modal('hide');
                location.reload();
            }
        });
    });
    // end delete user script

   // script for view case 
        $('.view').click(function(e) { 
          e.preventDefault();
        var user_id =  $(this).closest('tr').find('.user_id').text();

          $.ajax({
            type:'post',
            url:'view_case.php',
            data:{
                  'click_view_btn': true,
                  'user_id':user_id,
                }, 
            success:function(response){ 
                $('#view_data').html(response);
                $('#view').modal('show');
            }
        });
        });
    // 
    // end view case script 
});
</script>

</body>
</html>